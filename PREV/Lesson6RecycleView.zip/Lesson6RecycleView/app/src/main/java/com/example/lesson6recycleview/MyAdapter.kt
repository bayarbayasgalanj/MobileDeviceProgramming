package com.example.lesson6recycleview

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(var blist: ArrayList<Book>) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        // recycler is a type of viewcgroup
        // false already we attached to the parent
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list,parent,false)
        return MyViewHolder(view)
    }
    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int) {
        holder.tv_name.text = blist[position].name
        holder.tv_auth.text = blist[position].author

        if (position == 0) {
            holder.tv_name.setBackgroundColor(Color.DKGRAY)
            holder.tv_auth.setBackgroundColor(Color.TRANSPARENT)
        }
    }
    override fun getItemCount() = blist.count()

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        val tv_name : TextView = itemView.findViewById(R.id.name)
        val tv_auth : TextView = itemView.findViewById(R.id.author)
    }

}