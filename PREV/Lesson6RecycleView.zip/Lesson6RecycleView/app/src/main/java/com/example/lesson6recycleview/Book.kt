package com.example.lesson6recycleview

data class Book(val name: String, val author: String)
