package com.example.lesson6recycleview

data class Fruits(var fname: String, val finfo: String, val dinfo: String, val image: Int)
