package com.example.lesson6recycleview

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MyAdapter2(var context: Context, var text1: ArrayList<String>, var text2:Array<String>, var img:IntArray, var text3 : Array<String>) : RecyclerView.Adapter<MyAdapter2.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter2.MyViewHolder {
        // recycler is a type of viewcgroup
        // false already we attached to the parent
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list,parent,false)
        return MyViewHolder(view)
    }
    override fun onBindViewHolder(holder: MyAdapter2.MyViewHolder, position: Int) {
        holder.txt1.text = text1[position]
        holder.txt2.text = text2[position]
        holder.img.setImageResource(img[position])
        // Implement the click Listener in the using the layout.
        holder.rlayout.setOnClickListener{
            // User clicks the list Item to open the DetailActivity
            val intent = Intent(context, DetailActivity::class.java)
            var res = text1[position]
            Toast.makeText(context," $res clicked", Toast.LENGTH_LONG).show()
            // Pass data to the Detail Activity
            intent.putExtra("image", img[position])
            intent.putExtra("name", text1[position])
            intent.putExtra("detail",text3[position])
            context.startActivity(intent)
        }

//        if (position == 0) {
//            holder.tv_name.setBackgroundColor(Color.DKGRAY)
//            holder.tv_auth.setBackgroundColor(Color.TRANSPARENT)
//        }
    }
    override fun getItemCount() = text1.count()

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        val rlayout: RelativeLayout
        val txt1 : TextView
        val txt2 : TextView
        val img: ImageView

        init {
            rlayout = itemView.findViewById(R.id.playout) as RelativeLayout
            txt1 = itemView.findViewById(R.id.tv1) as TextView
            txt2 = itemView.findViewById(R.id.tv2) as TextView
            img = itemView.findViewById(R.id.imageView) as ImageView
        }

    }

}