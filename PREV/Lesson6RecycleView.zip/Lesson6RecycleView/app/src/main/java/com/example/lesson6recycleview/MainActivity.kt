package com.example.lesson6recycleview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lesson6recycleview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding

    var imageges = intArrayOf(
        R.drawable.apple,
        R.drawable.banana,
        R.drawable.cherries,
        R.drawable.dates,
        R.drawable.grapes,
        R.drawable.mango
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        //problem1()

        problem2()

    }

    fun problem2() {

        // Retrieve the array resources of data
        var s1 = resources.getStringArray(R.array.fruits);
        var s2 = resources.getStringArray(R.array.desc);
        var s3 = resources.getStringArray(R.array.detail);
        binding.recyclerView1.layoutManager = LinearLayoutManager(this)
        // Create an object for the MyAdapter
        //val adapter = MyAdapter2(this,s1 , s2 ,imageges,s3 )
        var adapter = MyAdapter2(this, s1, s2, imageges, s3)
        //class MyAdapter2(var context: Context, var text1: ArrayList<String>, var text2:Array<String>, var img:IntArray, var text3 : Array<String>)
        // Set adapter to your RecyclerView
        binding.recyclerView1.adapter = adapter

    }

    fun problem1() {
        val books = ArrayList<Book>()
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))

        var ad_ob = MyAdapter(books)
// Set the Layout Manager
        binding.recyclerView1.layoutManager = LinearLayoutManager(this)
        binding.recyclerView1.adapter = ad_ob
    }
}