# CVAPP
Group Assignment 2




Assignment to create CV APP



<div style="display:inline"> 
 <img src="screen1.png" width="150" >
 <img src="screen2.png" width="150" >
 <img src="screen3.png" width="150" >
 <img src="screen4.png" width="150" >
 <img src="screen5.png" width="150" >
</div>
