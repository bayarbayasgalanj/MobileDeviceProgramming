package com.example.cvapp.fragment

import androidx.fragment.app.Fragment
import com.example.cvapp.R


class ProjectsFragment : Fragment(R.layout.fragment_projects) {

}