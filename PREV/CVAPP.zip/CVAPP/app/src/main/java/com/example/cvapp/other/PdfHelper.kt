package com.example.cvapp.other

import android.content.Context
import android.content.Context.PRINT_SERVICE
import android.content.Intent
import android.graphics.pdf.PdfDocument.PageInfo
import android.net.Uri
import android.print.PrintAttributes
import android.print.pdf.PrintedPdfDocument
import android.widget.LinearLayout
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class PdfHelper: Runnable {

    private val contentPage: LinearLayout
    private val context: Context

    constructor(contentPage: LinearLayout, context: Context) {
        this.contentPage = contentPage
        this.context = context
        makeAndSharePDF()
    }

    private fun makeAndSharePDF() {
        Thread(this).start()
    }

    override fun run() {
        var printAttr = PrintAttributes.Builder()
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
            .setResolution(PrintAttributes.Resolution("zoey", PRINT_SERVICE, 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()


        var document = PrintedPdfDocument(context, printAttr)

        var pageInfo = PageInfo.Builder(300, 300, 1).create()

        var page = document.startPage(pageInfo)

        contentPage.draw(page.canvas)

        document.finishPage(page)

        try {
            val pdfDir = File(context.filesDir, "pdfs")
            pdfDir.mkdir()
            var file = File(pdfDir, "mycv.pdf")

            //val pkg = BuildConfig.APPLICATION_ID + ".provider"
            val pkg = "com.example.cvapp.provider"

            val os = FileOutputStream(file)
            document.writeTo(os)
            document.close()
            os.close()
            val contentUrl = FileProvider.getUriForFile(context, pkg, file)
            sharePDF(contentUrl)
        } catch (e: IOException) {
            println(e)
        }
    }

    private fun sharePDF(uri : Uri) {
        var intent = Intent()
        intent.action = Intent.ACTION_SEND
        intent.type = "application/pdf"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        context.startActivity(intent)
    }

}