package com.example.cvapp.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.cvapp.databinding.ActivityPdfBinding
import com.example.cvapp.other.PdfHelper
import java.util.*

class PdfActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfBinding.inflate(layoutInflater)
        setContentView(binding.root)


        PdfHelper(binding.root, Objects.requireNonNull(getApplicationContext()))
    }
}