package com.example.cvapp.other

class Constants {
    companion object {
        const val INTENT_VALUE = "intent_value"
    }
}