package com.example.cvapp.fragment

import androidx.fragment.app.Fragment
import com.example.cvapp.R


class HomeFragment : Fragment(
    R.layout.fragment_home
)