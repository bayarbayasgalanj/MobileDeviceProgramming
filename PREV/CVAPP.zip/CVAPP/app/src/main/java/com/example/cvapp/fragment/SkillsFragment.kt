package com.example.cvapp.fragment


import androidx.fragment.app.Fragment
import com.example.cvapp.R


class SkillsFragment : Fragment(R.layout.fragment_skills)