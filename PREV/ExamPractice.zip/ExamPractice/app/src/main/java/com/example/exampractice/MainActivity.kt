package com.example.exampractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebViewClient
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import com.example.exampractice.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private val loginDataStore by preferencesDataStore(name = "loginstore")
    private val NAME = stringPreferencesKey("UNAME")
    private val PASS = stringPreferencesKey("UPASS")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webview.loadUrl("https://www.google.com")
        binding.webview.webViewClient = WebViewClient()
        binding.webview.settings.javaScriptEnabled = true
        binding.webview.settings.builtInZoomControls = true

        lifecycleScope.launch {
            val userNameFlow = loginDataStore.data.map {
                it[NAME] ?: ""
            }

            println(userNameFlow.first().toString())
        }


        binding.btnBack.setOnClickListener {
            lifecycleScope.launch {
                writeDS("hello", "world")
            }

            if (binding.webview.canGoBack()) {
                binding.webview.goBack()
            }
        }

        binding.btnForward.setOnClickListener {
            if (binding.webview.canGoForward()) {
                binding.webview.goForward()
            }
        }


        binding.btnFacebook.setOnClickListener {
            binding.webview.loadUrl("https://www.facebook.com")
        }

        binding.btnGithub.setOnClickListener {
            binding.webview.loadUrl("https://www.github.com")
        }

        binding.btnYoutube.setOnClickListener {
            binding.webview.loadUrl("https://www.youtube.com")
        }
    }

    private suspend fun writeDS(name: String, pass: String) {
        loginDataStore.edit {
            it[NAME] = name
            it[PASS] = pass
        }

    }
}