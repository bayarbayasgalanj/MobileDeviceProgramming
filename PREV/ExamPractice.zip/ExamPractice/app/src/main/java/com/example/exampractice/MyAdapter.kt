package com.example.exampractice

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MyAdapter(var context: Context): RecyclerView.Adapter<MyAdapter.MyViewHolder>()  {
    var list:List<ImageData> = emptyList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row_data,parent,false)
        return MyViewHolder(view)
    }
    override fun getItemCount() = list.size
    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int) {
        holder.rowtext.text = list[position].name
        Glide.with(context).load(list[position].imageurl).into(holder.rowimage)
    }
    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var rowtext: TextView = itemView.findViewById(R.id.text)
        var rowimage: ImageView = itemView.findViewById(R.id.image)
    }

}