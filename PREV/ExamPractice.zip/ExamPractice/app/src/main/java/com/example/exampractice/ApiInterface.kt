package com.example.exampractice

import retrofit2.Response
import retrofit2.http.GET

interface ApiInterface {

    @GET(value = "/Oclemy/SampleJSON/338d9585/spacecrafts.json")
    suspend fun getImages(): Response<List<ImageData>>
}