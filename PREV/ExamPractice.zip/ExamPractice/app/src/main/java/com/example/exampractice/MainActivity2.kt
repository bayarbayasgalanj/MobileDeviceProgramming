package com.example.exampractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.example.exampractice.databinding.ActivityMain2Binding
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

class MainActivity2 : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)

        setContentView(binding.root)
    }

    private fun testApi() {
        val api = Retrofit.Builder()
            .baseUrl("http://www.google.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiInterface::class.java)

        lifecycleScope.launch {
            var response = api.getImages()
            if( response!!.isSuccessful){ // Check using non null !! operator
                response.body().let {
                    if (it != null) {
                        var items = it
                        println(items.forEach{ println(it) })

                    }
                }

            }
            else
            {
                Toast.makeText(applicationContext,"Failed to Retrieve  ", Toast.LENGTH_LONG).show()
            }
        }






    }
}