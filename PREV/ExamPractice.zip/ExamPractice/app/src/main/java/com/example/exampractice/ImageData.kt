package com.example.exampractice


data class ImageData(var id:Int,
                     var name:String,
                     var propellant:String,
                     var destination: String,
                     var imageurl:String,
                     var technologyexists:Int)
