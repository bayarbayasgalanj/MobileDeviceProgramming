package com.example.exampractice

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.exampractice.databinding.ActivityMain3Binding

class MainActivity3 : AppCompatActivity(), SensorEventListener {
    lateinit var binding: ActivityMain3Binding
    lateinit var lightSensor: Sensor
    lateinit var sm: SensorManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain3Binding.inflate(layoutInflater)


        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT)

        if (lightSensor == null) {
            Toast.makeText(this, "this device don't have light sensor", Toast.LENGTH_SHORT).show()
        }
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        sm.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(p0: SensorEvent) {
        TODO("Not yet implemented")
        if (p0.sensor.type == Sensor.TYPE_LIGHT) {
            val currentReading = p0.values[0]
            //lightmeter.progress = currentReading.toInt()
            //reading.text = ("Current Reading: "
            //        + (currentReading).toString() + " Lux")

        }
    }

    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
        TODO("Not yet implemented")

    }
}