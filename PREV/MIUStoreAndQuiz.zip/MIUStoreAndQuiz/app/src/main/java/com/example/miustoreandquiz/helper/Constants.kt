package com.example.miustoreandquiz.helper

class Constants {
    companion object {
        val INTENT_KEY = "intent_key"
        val INTENT_KEY2 = "intent_key2"
    }
}