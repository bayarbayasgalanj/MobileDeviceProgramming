package com.example.miustoreandquiz.helper

data class Product(val title: String,val id: String, val price: String, val image: String, val desc: String): java.io.Serializable
